package com.Menu.repositary;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Menu.entity.Menu;

@Repository
public interface MenuRepository extends JpaRepository<Menu,Integer>{

	// Custom Repository method
//	@Query(value = "select * from products where category_id=?1", nativeQuery = true)
	public List<Menu> findByRestaurantId(int restaurantId);
}
