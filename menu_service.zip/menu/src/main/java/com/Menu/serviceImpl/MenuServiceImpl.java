package com.Menu.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.Menu.client.RestaurantService;
import com.Menu.entity.Menu;
import com.Menu.exception.MenuNotFoundException;
import com.Menu.exception.NoSuchRestaurantException;
import com.Menu.repositary.MenuRepository;
import com.Menu.service.MenuService;
import com.Menu.dto.RestaurantDTO;

@Service
public class MenuServiceImpl implements MenuService {

    @Autowired
    private MenuRepository menuRepository;
    
    @Autowired
    private RestaurantService restaurantService;
    
   

    @Override
    public Menu addMenu(Menu menu) throws NoSuchRestaurantException {
        // Check if the restaurant exists
        RestaurantDTO restaurant = restaurantService.getRestaurantById(menu.getRestaurantId());
        if (restaurant == null) {
            throw new NoSuchRestaurantException("Invalid Restaurant id");
        }
        
        // Save the menu
        return menuRepository.save(menu);
    }

    @Override
    public Menu getById(int menuId) throws MenuNotFoundException {
        // Retrieve menu by ID
        return menuRepository.findById(menuId).orElseThrow(() -> new MenuNotFoundException("Invalid Menu Id"));
    }

    @Override
    public Menu updateMenu(int menuId, Menu menu) throws MenuNotFoundException {
        // Find menu by ID
        Menu existingMenu = menuRepository.findById(menuId).orElseThrow(() -> new MenuNotFoundException("Menu not found"));
        
        // Update menu details
        if (menu.getMenuName() != null)
            existingMenu.setMenuName(menu.getMenuName());
        if (menu.getRestaurantId() != 0)
            existingMenu.setRestaurantId(menu.getRestaurantId());
        if (menu.getMenuDescription() != null)
            existingMenu.setMenuDescription(menu.getMenuDescription());
        if (menu.getMenuPrice() != 0)
            existingMenu.setMenuPrice(menu.getMenuPrice());

        // Save updated menu
        return menuRepository.save(existingMenu);
    }

    @Override
    public String deleteMenu(int menuId) {
        try {
            Menu menu = menuRepository.findById(menuId).orElseThrow(() -> new MenuNotFoundException("Invalid Menu Id"));
            menuRepository.delete(menu);
        } catch (MenuNotFoundException e) {
            return "Invalid Menu Id";
        }
        return "Menu deleted";
    }

    @Override
    public List<Menu> getAllMenu() {
        return menuRepository.findAll();
    }

    @Override
    public List<Menu> getByRestaurantId(int restaurantId) throws NoSuchRestaurantException {
        // Check if the restaurant exists
        RestaurantDTO restaurant = restaurantService.getRestaurantById(restaurantId);
        if (restaurant == null) {
            throw new NoSuchRestaurantException("No restaurant found with ID: " + restaurantId);
        }
        
        // Find menus by restaurant ID
        return menuRepository.findByRestaurantId(restaurantId);
    }
    
    
    public RestaurantDTO getRestaurantById(@PathVariable int restaurantId)
    {
		return restaurantService.getRestaurantById(restaurantId);
    	
    }
    
}
