package com.Menu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Menu.client.RestaurantService;
import com.Menu.dto.RestaurantDTO;
import com.Menu.entity.Menu;
import com.Menu.exception.MenuNotFoundException;
import com.Menu.exception.NoSuchRestaurantException;
import com.Menu.service.MenuService;

@RestController
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;
    
    @Autowired
    private RestaurantService restaurantService;

    // Endpoint to add a new menu
    @PostMapping("/add")
    public Menu addMenu(@RequestBody Menu menu) throws NoSuchRestaurantException {
        return menuService.addMenu(menu);
    }

    // Endpoint to retrieve a menu by its ID
    @GetMapping("/getById/{menuId}")
    public Menu getMenuById(@PathVariable(value = "menuId") int menuId) throws MenuNotFoundException {
        return menuService.getById(menuId);
    }

    // Endpoint to update a menu
    @PutMapping("/updateMenu/{menuId}")
    public Menu updateMenu(@PathVariable(value = "menuId") int menuId, @RequestBody Menu menu) throws MenuNotFoundException {
        return menuService.updateMenu(menuId, menu);
    }

    // Endpoint to delete a menu by its ID
    @DeleteMapping("/deleteMenu/{menuId}")
    public String deleteMenu(@PathVariable(value = "menuId") int menuId) {
        return menuService.deleteMenu(menuId);
    }

    // Endpoint to retrieve all menus
    @GetMapping("/getAllMenu")
    public List<Menu> getAllMenus() {
        return menuService.getAllMenu();
    }

    // Endpoint to retrieve menus by restaurant ID
    @GetMapping("/getByRestaurantId/{restaurantId}")
    public List<Menu> getMenusByRestaurantId(@PathVariable(value = "restaurantId") int restaurantId) throws NoSuchRestaurantException {
        return menuService.getByRestaurantId(restaurantId);
    }
    
    @GetMapping("/{restaurantId}")
    public RestaurantDTO getRestaurantById(@PathVariable int restaurantId) {
        return restaurantService.getRestaurantById(restaurantId);
    }
}
