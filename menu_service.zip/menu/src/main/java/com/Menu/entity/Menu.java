package com.Menu.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name="Menudb")
public class Menu {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int menuId;
	
	private String menuName;
	
	private int restaurantId;

	private String menuDescription;
	
	private double menuPrice;
}
