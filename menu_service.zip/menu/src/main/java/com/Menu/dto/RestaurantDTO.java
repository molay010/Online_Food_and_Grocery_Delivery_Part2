package com.Menu.dto;


import lombok.Data;

@Data
public class RestaurantDTO {

	private int restaurantId;       
    private String restaurantName;            
    private String restaurantAddress;         
    private String restaurantCuisineType; 
}
