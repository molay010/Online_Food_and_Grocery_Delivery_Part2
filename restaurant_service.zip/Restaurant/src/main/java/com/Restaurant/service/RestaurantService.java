package com.Restaurant.service;

import java.util.List;

import com.Restaurant.entity.Restaurant;
import com.Restaurant.exception.RestaurantNotFoundException;

public interface RestaurantService {
    Restaurant addRestaurant(Restaurant restaurant);
    Restaurant updateRestaurant(int restaurantId, Restaurant restaurant) throws RestaurantNotFoundException;
    String deleteRestaurant(int restaurantId) throws RestaurantNotFoundException;
    Restaurant getRestaurantByName(String restaurantName);
    Restaurant getRestaurantById(int restaurantId) throws RestaurantNotFoundException;
    List<Restaurant> getAllRestaurants();
}
