package com.Restaurant.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Restaurant.entity.Restaurant;
import com.Restaurant.exception.RestaurantNotFoundException;
import com.Restaurant.repositary.RestaurantRepository;
import com.Restaurant.service.RestaurantService;

@Service
public class RestaurantServiceImpl implements RestaurantService {

    private static final Logger logger = LoggerFactory.getLogger(RestaurantServiceImpl.class);

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Override
    public Restaurant addRestaurant(Restaurant restaurant) {
        logger.info("Adding a new restaurant: {}", restaurant.getRestaurantName());
        return restaurantRepository.save(restaurant);
    }

    @Override
    public Restaurant updateRestaurant(int restaurantId, Restaurant restaurant) throws RestaurantNotFoundException {
        Restaurant existingRestaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant with ID " + restaurantId + " not found"));

        existingRestaurant.setRestaurantName(restaurant.getRestaurantName());
        existingRestaurant.setRestaurantAddress(restaurant.getRestaurantAddress());
        existingRestaurant.setRestaurantCuisineType(restaurant.getRestaurantCuisineType());
        existingRestaurant.setAdminId(restaurant.getAdminId());

        logger.info("Updating restaurant with ID: {}", restaurantId);
        return restaurantRepository.save(existingRestaurant);
    }

    @Override
    public String deleteRestaurant(int restaurantId) throws RestaurantNotFoundException {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant with ID " + restaurantId + " not found"));
        
        restaurantRepository.delete(restaurant);
        logger.info("Deleted restaurant with ID: {}", restaurantId);
        return "Restaurant with ID " + restaurantId + " has been deleted";
    }

    @Override
    public Restaurant getRestaurantByName(String restaurantName) {
        Restaurant restaurant = restaurantRepository.findByName(restaurantName);
        if (restaurant == null) {
            logger.warn("Restaurant with name {} not found", restaurantName);
            throw new RestaurantNotFoundException("Restaurant with name " + restaurantName + " not found");
        }
        return restaurant;
    }

    @Override
    public Restaurant getRestaurantById(int restaurantId) throws RestaurantNotFoundException {
        return restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant with ID " + restaurantId + " not found"));
    }

    @Override
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }
}
