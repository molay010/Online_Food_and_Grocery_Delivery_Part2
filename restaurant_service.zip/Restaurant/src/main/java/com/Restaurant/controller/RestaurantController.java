package com.Restaurant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Restaurant.entity.Restaurant;
import com.Restaurant.exception.RestaurantNotFoundException;
import com.Restaurant.service.RestaurantService;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService;

    @PostMapping("/add")
    public Restaurant addRestaurant(@RequestBody Restaurant restaurant) {
        return restaurantService.addRestaurant(restaurant);
    }

    @PutMapping("/{restaurantId}")
    public Restaurant updateRestaurant(@PathVariable int restaurantId, @RequestBody Restaurant restaurant) throws RestaurantNotFoundException {
        return restaurantService.updateRestaurant(restaurantId, restaurant);
    }

    @DeleteMapping("/{restaurantId}")
    public String deleteRestaurant(@PathVariable int restaurantId) throws RestaurantNotFoundException {
        return restaurantService.deleteRestaurant(restaurantId);
    }

    @GetMapping("/restaurantName/{restaurantName}")
    public Restaurant getRestaurantByName(@PathVariable String restaurantName) {
        return restaurantService.getRestaurantByName(restaurantName);
    }

    @GetMapping("/{restaurantId}")
    public Restaurant getRestaurantById(@PathVariable int restaurantId) throws RestaurantNotFoundException {
        return restaurantService.getRestaurantById(restaurantId);
    }

    @GetMapping
    public List<Restaurant> getAllRestaurants() {
        return restaurantService.getAllRestaurants();
    }
}
