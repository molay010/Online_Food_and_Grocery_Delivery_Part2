package com.Restaurant.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "restaurantdb")
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	 private int restaurantId;
	
	@NotNull
	 private int adminId;
	
	@NotNull
    @Size(min = 2, max = 50)
	 private String restaurantName;
	 
	@NotNull
	 private String restaurantAddress;
	 
	@NotNull
	 private String restaurantCuisineType;
	
	  
}
