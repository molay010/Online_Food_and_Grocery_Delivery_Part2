package com.cg;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.client.CartService;
import com.cg.dto.CartDTO;
import com.cg.dto.OrdersDTO;
import com.cg.entity.Orders;
import com.cg.entity.Status;
import com.cg.exception.CustomerNotFoundException;
import com.cg.exception.OrderNotFoundException;
import com.cg.repository.OrdersRepository;
import com.cg.serviceImpl.OrdersServiceImpl;

public class OrdersServiceTest {

    @Mock
    private OrdersRepository ordersRepository;

    @Mock
    private CartService cartService;

    @InjectMocks
    private OrdersServiceImpl ordersService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testAddOrders() throws CustomerNotFoundException {
        // Setup CartDTO
        CartDTO cartDTO = new CartDTO();
        cartDTO.setId(1);
        cartDTO.setCustomerId(1);
        cartDTO.setTotalItemPrice(100.0);
        cartDTO.setTotalItemQuantity(2);

        // Mock the cartService to return the cartDTO
        when(cartService.getCartByCustomerId(1)).thenReturn(cartDTO);

        // Setup Orders entity
        Orders order = new Orders();
        order.setCustomerId(1);
        order.setOredrDate(LocalDateTime.now());
        order.setOrderStatus(Status.PENDING);
        order.setCart_id(1);

        // Mock the ordersRepository to return the order
        when(ordersRepository.save(any())).thenReturn(order);

        // Setup OrdersDTO
        OrdersDTO ordersDTOInput = new OrdersDTO();
        ordersDTOInput.setCustomerId(1);
        ordersDTOInput.setCart_id(1);
        ordersDTOInput.setOrderStatus(Status.PENDING);

        // Call the method under test
        OrdersDTO result = ordersService.addOrders(ordersDTOInput);

        // Assertions
        assertEquals(1, result.getCustomerId());
        assertEquals(1, result.getCart_id());
        assertEquals(Status.PENDING, result.getOrderStatus());
    }

    @Test
    void testAddOrdersInvalidCustomer() {
        // Mock cartService to return null for invalid customer
        when(cartService.getCartByCustomerId(1)).thenReturn(null);

        // Setup OrdersDTO
        OrdersDTO ordersDTOInput = new OrdersDTO();
        ordersDTOInput.setCustomerId(1);

        // Assert exception is thrown
        assertThrows(CustomerNotFoundException.class, () -> {
            ordersService.addOrders(ordersDTOInput);
        });
    }

    @Test
    void testGetById() throws OrderNotFoundException {
        Orders order = new Orders();
        order.setOrderId(1);
        order.setCustomerId(1);
        order.setCart_id(1);
        order.setOrderStatus(Status.PENDING);

        when(ordersRepository.findById(1)).thenReturn(Optional.of(order));

        OrdersDTO ordersDTO = ordersService.getById(1);

        assertEquals(1, ordersDTO.getOrderId());
        assertEquals(1, ordersDTO.getCustomerId());
        assertEquals(1, ordersDTO.getCart_id());
        assertEquals(Status.PENDING, ordersDTO.getOrderStatus());
    }

    @Test
    void testGetByIdInvalidOrder() {
        when(ordersRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> {
            ordersService.getById(1);
        });
    }

    @Test
    void testFindAll() {
        List<Orders> ordersList = new ArrayList<>();
        Orders order1 = new Orders();
        order1.setOrderId(1);
        order1.setCustomerId(1);
        order1.setCart_id(1);
        order1.setOrderStatus(Status.PENDING);
        Orders order2 = new Orders();
        order2.setOrderId(2);
        order2.setCustomerId(2);
        order2.setCart_id(2);
        order2.setOrderStatus(Status.ACCEPTED);
        ordersList.add(order1);
        ordersList.add(order2);

        when(ordersRepository.findAll()).thenReturn(ordersList);

        List<OrdersDTO> ordersDTOList = ordersService.findAll();

        assertEquals(2, ordersDTOList.size());
        assertEquals(1, ordersDTOList.get(0).getOrderId());
        assertEquals(2, ordersDTOList.get(1).getOrderId());
    }

    @Test
    void testDeleteOrders() {
        when(ordersRepository.findById(1)).thenReturn(Optional.of(new Orders()));

        String result = ordersService.deleteOrders(1);

        assertEquals("Deleted Successfully", result);
        verify(ordersRepository, times(1)).deleteById(1);
    }

    @Test
    void testDeleteOrdersInvalidOrder() {
        when(ordersRepository.findById(1)).thenReturn(Optional.empty());

        String result = ordersService.deleteOrders(1);

        assertEquals("Invalid order ID", result);
        verify(ordersRepository, never()).deleteById(1);
    }

    @Test
    void testGetOrderCustomerId() {
        List<Orders> ordersList = new ArrayList<>();
        Orders order1 = new Orders();
        order1.setOrderId(1);
        order1.setCustomerId(1);
        order1.setCart_id(1);
        order1.setOrderStatus(Status.PENDING);
        Orders order2 = new Orders();
        order2.setOrderId(2);
        order2.setCustomerId(1);
        order2.setCart_id(2);
        order2.setOrderStatus(Status.ACCEPTED);
        ordersList.add(order1);
        ordersList.add(order2);

        when(ordersRepository.findByCustomerId(1)).thenReturn(ordersList);

        List<OrdersDTO> ordersDTOList = ordersService.getOrderCustomerId(1);

        assertEquals(2, ordersDTOList.size());
        assertEquals(1, ordersDTOList.get(0).getOrderId());
        assertEquals(2, ordersDTOList.get(1).getOrderId());
    }


}