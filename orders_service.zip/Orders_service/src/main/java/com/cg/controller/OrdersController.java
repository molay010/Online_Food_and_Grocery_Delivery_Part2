package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.OrdersDTO;
import com.cg.exception.CustomerNotFoundException;
import com.cg.exception.OrderNotFoundException;
import com.cg.service.OrdersService;

@RestController
@RequestMapping("/orders")
//@CrossOrigin(origins = "http://localhost:3000/")	// Frontend Connection
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    // Endpoint to add orders for a customer
    @PostMapping("/add")
    public OrdersDTO addOrders(@RequestBody OrdersDTO ordersDTO) throws CustomerNotFoundException {
        return ordersService.addOrders(ordersDTO);
    }

    // Endpoint to get an order by ID
    @GetMapping("getById/{orderId}")
    public OrdersDTO getOrderById(@PathVariable("orderId") int orderId) throws OrderNotFoundException {
        return ordersService.getById(orderId);
    }

    // Endpoint to get all orders
    @GetMapping("/findAll")
    public List<OrdersDTO> getAllOrders() {
        return ordersService.findAll();
    }

    // Endpoint to delete an order by ID
    @DeleteMapping("/delete/{orderId}")
    public String deleteOrders(@PathVariable("orderId") int orderId) {
        return ordersService.deleteOrders(orderId);
    }
}
