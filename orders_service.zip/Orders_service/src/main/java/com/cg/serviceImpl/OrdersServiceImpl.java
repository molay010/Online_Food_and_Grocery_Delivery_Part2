package com.cg.serviceImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.CartService;
import com.cg.client.CustomerService;
import com.cg.dto.CartDTO;
import com.cg.dto.OrdersDTO;
import com.cg.entity.Orders;
import com.cg.entity.Status;
import com.cg.exception.CustomerNotFoundException;
import com.cg.exception.OrderNotFoundException;
import com.cg.repository.OrdersRepository;
import com.cg.service.OrdersService;

@Service
public class OrdersServiceImpl implements OrdersService {

    // Autowiring necessary services and repositories
    @Autowired
    private CartService cartService;
    @Autowired
    private OrdersRepository ordersRepository;
    @Autowired
    private CustomerService customerService;

    // Method to add orders for a given customer
    @Override
    public OrdersDTO addOrders(OrdersDTO ordersDTO) throws CustomerNotFoundException {
        // Validate and get the cart associated with the customer from the DTO
        CartDTO cart = cartService.getCartByCustomerId(ordersDTO.getCustomerId());
        if (cart == null) {
            throw new CustomerNotFoundException("Invalid customer Id");
        }

        // Creating a new order based on the DTO details
        Orders order = new Orders();
        order.setCustomerId(ordersDTO.getCustomerId());
        order.setOredrDate(LocalDateTime.now());
        order.setOrderStatus(Status.PENDING); // Set status as pending or map from DTO if needed
        order.setCart_id(ordersDTO.getCart_id());   //cartId

        // Save the order in the repository
        Orders savedOrder = ordersRepository.save(order);

        // Deleting the cart associated with the order
        cartService.deleteCart(cart.getId());

        // Map the saved order entity to DTO and return
        return mapOrdersToDTO(savedOrder);
    }


    // Method to retrieve an order by its ID
    @Override
    public OrdersDTO getById(int id) throws OrderNotFoundException {

        // Retrieve the order from the repository
        Orders order = ordersRepository.findById(id).orElse(null);
        if (order == null) {
            throw new OrderNotFoundException("Invalid order ID");
        }

        return mapOrdersToDTO(order); // Map the entity to DTO and return
    }

    // Method to retrieve all orders
    @Override
    public List<OrdersDTO> findAll() {

        // Retrieve all orders from the repository
        List<Orders> orders = ordersRepository.findAll();

        List<OrdersDTO> ordersDTOs = new ArrayList<OrdersDTO>();
        for (Orders order : orders) {
            ordersDTOs.add(mapOrdersToDTO(order)); // Map each entity to DTO and add to the list
        }

        return ordersDTOs;
    }

    // Method to delete an order by its ID
    @Override
    public String deleteOrders(int orderId) {

        try {
            ordersRepository.findById(orderId).orElseThrow(() -> new OrderNotFoundException());
            ordersRepository.deleteById(orderId);

        } catch (OrderNotFoundException e) {
            return "Invalid order ID";
        }
        return "Deleted Successfully";
    }

    // Method to retrieve orders by customer ID
    @Override
    public List<OrdersDTO> getOrderCustomerId(int customerId) {

        List<Orders> orders = ordersRepository.findByCustomerId(customerId);

        List<OrdersDTO> ordersDTOs = new ArrayList<OrdersDTO>();

        for (Orders order : orders) {
            ordersDTOs.add(mapOrdersToDTO(order)); // Map each entity to DTO and add to the list
        }
        return ordersDTOs;
    }


    // Utility method to map Orders entity to DTO
    private OrdersDTO mapOrdersToDTO(Orders order) {
        OrdersDTO orderDto = new OrdersDTO();
        orderDto.setOrderId(order.getOrderId());
        orderDto.setCustomerId(order.getCustomerId());
        orderDto.setCart_id(order.getCart_id());                //cartid
        orderDto.setOredrDate(order.getOredrDate());
        orderDto.setOrderStatus(order.getOrderStatus());

        return orderDto;
    }
}
