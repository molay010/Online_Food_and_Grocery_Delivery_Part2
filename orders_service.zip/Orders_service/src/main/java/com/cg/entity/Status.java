package com.cg.entity;

public enum Status {
	DELIVERED, PENDING, ACCEPTED
}
