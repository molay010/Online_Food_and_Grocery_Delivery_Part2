package com.cg.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.cg.entity.Status;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class OrdersDTO {
    private int orderId;
	
	private int cart_id;

	private int customerId;
	
    private LocalDateTime oredrDate;
	
	private Status orderStatus;
}
